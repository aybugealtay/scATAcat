scATAcat package
================

Submodules
----------

scATAcat.bulk\_data\_functions module
-------------------------------------

.. automodule:: scATAcat.bulk_data_functions
   :members:
   :undoc-members:
   :show-inheritance:

scATAcat.helper\_functions module
---------------------------------

.. automodule:: scATAcat.helper_functions
   :members:
   :undoc-members:
   :show-inheritance:

scATAcat.plot\_functions module
-------------------------------

.. automodule:: scATAcat.plot_functions
   :members:
   :undoc-members:
   :show-inheritance:

scATAcat.pseudobulk\_functions module
-------------------------------------

.. automodule:: scATAcat.pseudobulk_functions
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: scATAcat
   :members:
   :undoc-members:
   :show-inheritance:
