# **scATAcat: scATAC-seq cluster annotation tool**


![alt text] (/project/scATAC_analysis/scATAcat_package/scATAcat/logo/logo.svg)

scATAcat is a tool for annotation of cell-types in scATAC-seq data based on characterized bulk ATAC-seq data. 

## Installation

You can install the library with:

``` 
pip install scatacat

```