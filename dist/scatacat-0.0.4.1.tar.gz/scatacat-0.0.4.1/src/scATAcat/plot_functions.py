import numpy as np 
import matplotlib 
import matplotlib.pylab as plt
import seaborn as sns
from sklearn.decomposition import PCA
import pandas as pd
import anndata
from scipy.spatial.distance import cdist, pdist, squareform
import seaborn as sns; sns.set_theme(color_codes=True)
np.random.seed(1234)

def cell_feature_statistics(adata, binary_layer_key ='binary'):
    '''
    Calculates the cell and feature statistics and adds them to AnnData.
        
    Parameters:
    - adata (AnnData): An AnnData object containing the sc count matrix.
    - binary_layer_key (str, optional): The key for accessing the layer to calculates the cell and feature statistics, Default 'binary'.

    Returns:
    AnnData with the following features:
        - num_cell_per_feature: how many cells have a count for a feature? / number of cells sharing a feature
        - num_feature_per_cell : how many features are open for a cell? / number of features in a cell
    
    '''
    if not binary_layer_key in adata.layers:
        add_binary_layer(adata, binary_layer_key=binary_layer_key)
    num_cell_per_feature = adata.layers[binary_layer_key].sum(0)
    num_feature_per_cell = adata.layers[binary_layer_key].sum(1)
    # cast the results to array to match the original matrix size
    adata.varm['num_cell_per_feature'] = np.squeeze(np.asarray(num_cell_per_feature))
    adata.obsm['num_feature_per_cell'] = np.squeeze(np.asarray(num_feature_per_cell))
    return adata
    
def plot_cell_statistics(adata, binary_layer_key ='binary', color=None, edgecolor=None, bins=None, xlabel=None, ylabel=None, title=None, threshold=None, save=False, save_dir=None, dpi=300):
    '''
    Plots the cell statistics. In simpler terms, this method shows how densely features are occupied by cells.
    It provides a visual representation of the distribution and concentration of these cells within the features.

    Parameters:
    - adata (AnnData): An AnnData object containing the sc count matrix.
    - binary_layer_key (str, optional): The key for accessing the layer to calculate the cell and feature statistics, Default 'binary'.
    - save (bool, optional): Whether or not to save the figure, Default False. 
    - save_dir (str, optional): Directory to sace the figure. Default None and saves to current directory. 
    - dpi (str, optional): resolution of the figure to save in dots per inch
    - kwds
        Are passed to :func:`matplotlib.pyplot.hist`.

    Returns:
    - AnnData obejct with following features: 
        - num_cell_per_feature (int): how many cells have a count for a feature? / number of cells sharing a feature
        - num_feature_per_cell : how many features are open for a cell? / number of features in a cell
        
    - Cell statistic plot

    '''
    
    if  'num_cell_per_feature' not in adata.varm_keys() and 'num_feature_per_cell' not in adata.obs_keys():
        print("calculating cell and feature statistics")
        cell_feature_statistics(adata, binary_layer_key =binary_layer_key)
    # plotting settings
    if xlabel ==None:
        plt.xlabel('cells')
    else:
        plt.xlabel(xlabel)

    if ylabel ==None:
        plt.ylabel('frequency of features')
    else:
        plt.ylabel(ylabel)

    if title !=None:
        plt.title(title)

    if color == None:
        color='c'
    if edgecolor == None:
        edgecolor='k'

    if bins == None:
        bins=50

    plt.rcParams['axes.facecolor'] = 'none'
    
    fig = plt.hist(adata.obsm['num_feature_per_cell'], bins, color=color, edgecolor=edgecolor)

    if threshold != None:
        plt.axvline(x=threshold, color='r', linestyle='--')
        
    if save == True:
        if save_dir is not None:
            plt.savefig(save_dir, dpi=dpi)
        else:
            plt.savefig("./",dpi=dpi)
    return adata



def plot_feature_statistics(adata, binary_layer_key ='binary', color=None, edgecolor=None, bins=None, xlabel=None, ylabel=None, title=None, threshold=None, save=False, save_dir=None, dpi=300):
    '''
    Plots the feature statistics. In simpler terms, this method shows how densely cells are occupied by features.
    It provides a visual representation of the distribution and concentration of these features within the cells.

    Parameters:
    - adata (AnnData): An AnnData object containing the sc count matrix.
    - binary_layer_key (str, optional): The key for accessing the layer to calculate the cell and feature statistics, Default 'binary'.
    - save (bool, optional): Whether or not to save the figure, Default False. 
    - save_dir (str, optional): Directory to sace the figure. Default None and saves to current directory. 
    - dpi (str, optional): resolution of the figure to save in dots per inch
    - kwds
        Are passed to :func:`matplotlib.pyplot.hist`.

    Returns:
    - AnnData obejct with following features: 
        - num_cell_per_feature (int): how many cells have a count for a feature? / number of cells sharing a feature
        - num_feature_per_cell : how many features are open for a cell? / number of features in a cell
        
    - Feature statistic plot 
    '''
    
    if  'num_cell_per_feature' not in adata.varm_keys() and 'num_feature_per_cell' not in adata.obs_keys():
        print("calculating cell and feature statistics")
        cell_feature_statistics(adata, binary_layer_key =binary_layer_key)
    # plotting settings
    if xlabel ==None:
        plt.xlabel('features')
    else:
        plt.xlabel(xlabel)

    if ylabel ==None:
        plt.ylabel('frequency of cells')
    else:
        plt.ylabel(ylabel)

    if title !=None:
        plt.title(title)

    if color == None:
        color='c'
    if edgecolor == None:
        edgecolor='k'

    if bins == None:
        bins=50
    plt.rcParams['axes.facecolor'] = 'none'
    
    fig = plt.hist(adata.varm['num_cell_per_feature'], bins, color=color, edgecolor=edgecolor)

    if threshold != None:
        plt.axvline(x=threshold, color='r', linestyle='--')
        
    if save == True:
        if save_dir is not None:
            plt.savefig(save_dir, dpi=dpi)
        else:
            plt.savefig("./",dpi=dpi)    
    return adata


################################################################################################################
# PROJECTION 
################################################################################################################

def projection(bulk_adata, pseudobulk_adata, bulk_layer_key = "libsize_norm_log2_std", pseudobulk_layer_key="libsize_norm_log2_bulk_scaled"):
    '''
    3D PCA projection of prototypes and pseudobulks. 

    Parameters:
    - bulk_adata (AnnData): An AnnData object containing the prototype count matrix.
    - pseudobulk_adata(AnnData): An AnnData object containing the pseudobulk count matrix.
    - bulk_layer_key (str): The key for accessing the prototype layer for projection. Default 'libsize_norm_log2_std'.
    - pseudobulk_layer_key (str): The key for accessing the pseudobulk layer for projection. Default 'libsize_norm_log2_bulk_scaled'

    Returns: 
    - 3D PCA projection figure.
    - PCA transformed values of prototypes.
    - PCA transformed values of pseudbulks.

    '''
    num_of_bulk_samples = bulk_adata.n_obs
    if num_of_bulk_samples >30:
        n_comp = 30
    else:
        n_comp = num_of_bulk_samples
    pca_bulk = PCA(n_components=n_comp)
    pca_bulk_train = pca_bulk.fit_transform(bulk_adata.layers[bulk_layer_key])
    PCs_pseudobulk_projection = pca_bulk.transform(pseudobulk_adata.layers[pseudobulk_layer_key])


    trained_bulk_pca_df = pd.DataFrame(data = pca_bulk_train
                 , columns = ["principal component " + str(i) for i in range(n_comp)])
    trained_bulk_pca_df["targets"] = bulk_adata.obs.index
    trained_bulk_pca_df

    projected_pseudobulk_pca_df = pd.DataFrame(data = PCs_pseudobulk_projection
                 , columns = ["principal component " + str(i) for i in range(n_comp)])
    projected_pseudobulk_pca_df["targets"] = pseudobulk_adata.obs.index
    projected_pseudobulk_pca_df

    trained_bulk_pca_df_w_labels = trained_bulk_pca_df.copy()
    trained_bulk_pca_df_w_labels["cell_type"] = trained_bulk_pca_df_w_labels['targets'].apply(lambda r: '_'.join(r.split('_')[:-1]))
    my_color=pd.Series(pd.Categorical(trained_bulk_pca_df_w_labels["cell_type"])).cat.codes
    trained_bulk_pca_df_w_labels["color_id"] = my_color
    ## plot
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    PC1 = trained_bulk_pca_df_w_labels['principal component 0'].values
    PC2 = trained_bulk_pca_df_w_labels['principal component 1'].values
    PC3 = trained_bulk_pca_df_w_labels['principal component 2'].values

    CELLTYPES = trained_bulk_pca_df_w_labels["cell_type"].values
    CELLTYPES_ = np.unique(CELLTYPES)

    COLORS = ['tab:red',
     '#170E9C',
     'gold',
     "tab:pink","tab:green","tab:orange",
     '#C2EA8C',
     '#FB8B8C',
     '#41AC58',
     '#548E0F',
     '#59DE8C',
     '#68EBC0',
     '#6C397C',
     '#7B1A94',
     '#92F026',
     '#9C8244',
     '#9F84A8',
     '#A05529',
     '#AEB916',
     '#BB6AB9',
     '#C2EA8C',
     '#C3DB06',
     '#DB52E0',
     '#DD9340',
     '#E231B2',
     '#F1D7F2',
     '#F5A04D',
     '#FB8B8C']
    for cell_type1, color in zip(CELLTYPES_, COLORS):
        idxs = np.where(CELLTYPES == cell_type1)
        # No legend will be generated if we don't pass label=species
        ax.scatter(
            PC1[idxs,], PC2[idxs,],PC3[idxs,], label=cell_type1,
            s=90, color=color, alpha=0.7, marker = "v"
        )

    BULK_CELLTYPES = projected_pseudobulk_pca_df["targets"].values
    CELLTYPES_ = np.unique(BULK_CELLTYPES)
    PC1_ = projected_pseudobulk_pca_df['principal component 0'].values
    PC2_ = projected_pseudobulk_pca_df['principal component 1'].values
    PC3_ = projected_pseudobulk_pca_df['principal component 2'].values
    COLORS_ = ['#95D113', '#C3B80F', 'purple', '#ED1B36', 'steelblue', '#ED70AE', 'blueviolet', '#DD5BE5', 'orange', 'green', 'turquoise', 'indigo', 'brown', 'olive', '#B467A4', 'dimgrey', '#fffe7a', '#C3B80F', 'brown', 'magenta']
    for bulk_cell_type1, color in zip(CELLTYPES_, COLORS_):

        idxs = np.where(BULK_CELLTYPES == bulk_cell_type1)
        # No legend will be generated if we don't pass label=bulk_cell_type1
        ax.scatter(
            PC1_[idxs,], PC2_[idxs,],PC3_[idxs,], label=bulk_cell_type1,
            s=50, color=color, alpha=0.9)

    # put labels on the plot
    m= np.array([list(PC1_),list(PC2_),list(PC3_)])
    for i in range(len(m[0])): #plot each point + it's index as text above
        ax.text(m[0,i],m[1,i],m[2,i],  '%s' % ('  ' +BULK_CELLTYPES[i]))


    #fig
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")
    ax.set_zlabel("PC3")
    ax.set_facecolor('white')
    ax.legend( ncol=2,handleheight=2.4, labelspacing=0.05, bbox_to_anchor=(0.9, 0.5, 0.8, 0.5))
    figure = plt.gcf() # get current figure
    figure.set_size_inches(20 ,30)
    return fig, trained_bulk_pca_df_w_labels,projected_pseudobulk_pca_df

def projection_only_bulk(bulk_adata, pseudobulk_adata, bulk_layer_key = "libsize_norm_log2_std", pseudobulk_layer_key="libsize_norm_log2_bulk_scaled"):
    '''
    3D PCA projection of prototypes. 

    Parameters:
    - bulk_adata (AnnData): An AnnData object containing the prototype count matrix.
    - pseudobulk_adata(AnnData): An AnnData object containing the pseudobulk count matrix.
    - bulk_layer_key (str): The key for accessing the prototype layer for projection. Default 'libsize_norm_log2_std'.
    - pseudobulk_layer_key (str): The key for accessing the pseudobulk layer for projection. Default 'libsize_norm_log2_bulk_scaled'

    Returns: 
    - 3D PCA projection of ptototypes.

    '''
    num_of_bulk_samples = bulk_adata.n_obs
    if num_of_bulk_samples >30:
        n_comp = 30
    else:
        n_comp = num_of_bulk_samples
    pca_bulk = PCA(n_components=n_comp)
    pca_bulk_train = pca_bulk.fit_transform(bulk_adata.layers[bulk_layer_key])
    PCs_pseudobulk_projection = pca_bulk.transform(pseudobulk_adata.layers[pseudobulk_layer_key])


    trained_bulk_pca_df = pd.DataFrame(data = pca_bulk_train
                 , columns = ["principal component " + str(i) for i in range(n_comp)])
    trained_bulk_pca_df["targets"] = bulk_adata.obs.index
    trained_bulk_pca_df

    projected_pseudobulk_pca_df = pd.DataFrame(data = PCs_pseudobulk_projection
                 , columns = ["principal component " + str(i) for i in range(n_comp)])
    projected_pseudobulk_pca_df["targets"] = pseudobulk_adata.obs.index
    projected_pseudobulk_pca_df

    trained_bulk_pca_df_w_labels = trained_bulk_pca_df.copy()
    trained_bulk_pca_df_w_labels["cell_type"] = trained_bulk_pca_df_w_labels['targets'].apply(lambda r: '_'.join(r.split('_')[:-1]))
    my_color=pd.Series(pd.Categorical(trained_bulk_pca_df_w_labels["cell_type"])).cat.codes
    trained_bulk_pca_df_w_labels["color_id"] = my_color
    ## plot
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    PC1 = trained_bulk_pca_df_w_labels['principal component 0'].values
    PC2 = trained_bulk_pca_df_w_labels['principal component 1'].values
    PC3 = trained_bulk_pca_df_w_labels['principal component 2'].values

    CELLTYPES = trained_bulk_pca_df_w_labels["cell_type"].values
    CELLTYPES_ = np.unique(CELLTYPES)

    COLORS = ['tab:red',
     '#170E9C',
     'gold',
     'tab:pink',
     'tab:green',
     '#F5A04D',
     '#C2EA8C',
     '#41AC58',
     '#548E0F',
     '#59DE8C',
     '#68EBC0',
     '#6C397C',
     '#7B1A94',
     '#92F026',
     '#9C8244',
     '#9F84A8',
     '#A05529',
     '#AEB916',
     '#BB6AB9',
     '#C2EA8C',
     '#C3DB06',
     '#DB52E0',
     '#DD9340',
     '#E231B2',
     '#F1D7F2',
     '#F5A04D',
     '#FB8B8C']
    for cell_type1, color in zip(CELLTYPES_, COLORS):
        idxs = np.where(CELLTYPES == cell_type1)
        # No legend will be generated if we don't pass label=species
        ax.scatter(
            PC1[idxs,], PC2[idxs,],PC3[idxs,], label=cell_type1,
            s=90, color=color, alpha=0.7, marker = "v"
        )

    BULK_CELLTYPES = projected_pseudobulk_pca_df["targets"].values
    CELLTYPES_ = np.unique(BULK_CELLTYPES)
    PC1_ = projected_pseudobulk_pca_df['principal component 0'].values
    PC2_ = projected_pseudobulk_pca_df['principal component 1'].values
    PC3_ = projected_pseudobulk_pca_df['principal component 2'].values
    COLORS_ = ['#95D113', '#C3B80F', 'purple', '#ED1B36', 'steelblue', '#ED70AE', 'blueviolet', '#DD5BE5', 'orange', 'green', 'magenta', 'indigo', 'brown', 'olive', '#B467A4', '#ffa756','#C3B80F', 'turquoise', 'brown' ]
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")
    ax.set_zlabel("PC3")
    ax.set_facecolor('white')
    #ax.legend(loc='best', bbox_to_anchor=(0.9, 0.8, 0.6, 0.5));
    ax.legend( ncol=2,handleheight=2.4, labelspacing=0.05, bbox_to_anchor=(0.9, 0.5, 0.8, 0.5))
    figure = plt.gcf() # get current figure
    figure.set_size_inches(20 ,30)
    return fig

# projection with matching color scheme between clusters and pseudobulks
def projection_match_colors(bulk_adata, pseudobulk_adata, bulk_layer_key = "libsize_norm_log2_std", pseudobulk_layer_key="libsize_norm_log2_bulk_scaled", color_key="clustering_color", label_font_size =18):
    
    '''
    3D PCA projection of prototypes and pseudobulks. Matches the pseudobulk colors to tthe clustering color if color_key is present in pseudobulk_adata.

    Parameters:
    - bulk_adata (AnnData): An AnnData object containing the prototype count matrix.
    - pseudobulk_adata(AnnData): An AnnData object containing the pseudobulk count matrix.
    - bulk_layer_key (str): The key for accessing the prototype layer for projection. Default 'libsize_norm_log2_std'.
    - pseudobulk_layer_key (str): The key for accessing the pseudobulk layer for projection. Default 'libsize_norm_log2_bulk_scaled'
    - color_key (str, optional): The key for accessing the cluster colors in the sc data. If provided, the pseudobulk points will be colored based on the cluster colors they originated from.
    - label_font_size (int): Font size of the labels on the PCA projection. 

    Returns: 
    - 3D PCA projection figure.
    - PCA transformed values of prototypes.
    - PCA transformed values of pseudbulks.

    '''
    
    num_of_bulk_samples = bulk_adata.n_obs
    if num_of_bulk_samples >30:
        n_comp = 30
    else:
        n_comp = num_of_bulk_samples
    pca_bulk = PCA(n_components=n_comp)
    pca_bulk_train = pca_bulk.fit_transform(bulk_adata.layers[bulk_layer_key])
    PCs_pseudobulk_projection = pca_bulk.transform(pseudobulk_adata.layers[pseudobulk_layer_key])


    trained_bulk_pca_df = pd.DataFrame(data = pca_bulk_train
                 , columns = ["principal component " + str(i) for i in range(n_comp)])
    trained_bulk_pca_df["targets"] = bulk_adata.obs.index
    trained_bulk_pca_df

    projected_pseudobulk_pca_df = pd.DataFrame(data = PCs_pseudobulk_projection
                 , columns = ["principal component " + str(i) for i in range(n_comp)])
    projected_pseudobulk_pca_df["targets"] = pseudobulk_adata.obs.index
    projected_pseudobulk_pca_df

    trained_bulk_pca_df_w_labels = trained_bulk_pca_df.copy()
    trained_bulk_pca_df_w_labels["cell_type"] = trained_bulk_pca_df_w_labels['targets'].apply(lambda r: '_'.join(r.split('_')[:-1]))
    my_color=pd.Series(pd.Categorical(trained_bulk_pca_df_w_labels["cell_type"])).cat.codes
    trained_bulk_pca_df_w_labels["color_id"] = my_color
    ## plot
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    PC1 = trained_bulk_pca_df_w_labels['principal component 0'].values
    PC2 = trained_bulk_pca_df_w_labels['principal component 1'].values
    PC3 = trained_bulk_pca_df_w_labels['principal component 2'].values

    CELLTYPES = trained_bulk_pca_df_w_labels["cell_type"].values
    CELLTYPES_ = np.unique(CELLTYPES)
    num_bulk_cell_types= len(CELLTYPES_)
    # colors for bulk samples 
    COLORS = ['tab:red',
         '#170E9C',
         "tab:gray",
         "tab:pink","tab:green","tab:orange",
         '#C2EA8C',
         '#FB8B8C',
         '#41AC58',
         '#548E0F',
         '#59DE8C',
         '#68EBC0',
         '#6C397C',
         '#7B1A94',
         '#92F026',
         '#9C8244',
         '#9F84A8',
         '#A05529',
         '#AEB916',
         '#BB6AB9',
         '#C2EA8C',
         '#C3DB06',
         '#DB52E0',
         '#DD9340',
         '#E231B2',
         '#F1D7F2',
         '#F5A04D',
         '#FB8B8C']
    for cell_type1, color in zip(CELLTYPES_, COLORS):
        idxs = np.where(CELLTYPES == cell_type1)
        # No legend will be generated if we don't pass label=species
        ax.scatter(
            PC1[idxs,], PC2[idxs,],PC3[idxs,], label=cell_type1,
            s=200, color=color, alpha=0.7, marker = "v"
        )

    BULK_CELLTYPES = projected_pseudobulk_pca_df["targets"].values
    CELLTYPES_ = np.unique(BULK_CELLTYPES)
    PC1_ = projected_pseudobulk_pca_df['principal component 0'].values
    PC2_ = projected_pseudobulk_pca_df['principal component 1'].values
    PC3_ = projected_pseudobulk_pca_df['principal component 2'].values
    COLORS_ =pseudobulk_adata.uns[color_key]
    for bulk_cell_type1, color in zip(CELLTYPES_, COLORS_):
        idxs = np.where(BULK_CELLTYPES == bulk_cell_type1)
        # No legend will be generated if we don't pass label=species
        ax.scatter(
            PC1_[idxs,], PC2_[idxs,],PC3_[idxs,], label=bulk_cell_type1,
            s=150, color=color, alpha=0.9)

    # put labels on the plot
    m= np.array([list(PC1_),list(PC2_),list(PC3_)])
    for i in range(len(m[0])): #plot each point + it's index as text above
        ax.text(m[0,i],m[1,i],m[2,i],  '%s' % ('  ' +BULK_CELLTYPES[i]), fontsize=label_font_size)


    #fig
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")
    ax.set_zlabel("PC3")
    ax.set_facecolor('white')
    ax.legend( ncol=2,handleheight=2.4, labelspacing=0.05, bbox_to_anchor=(0.9, 0.5, 0.8, 0.5))
    figure = plt.gcf() # get current figure
    figure.set_size_inches(20 ,30)
    return fig, trained_bulk_pca_df_w_labels,projected_pseudobulk_pca_df

def projection_match_colors_custom(bulk_adata, pseudobulk_adata, bulk_layer_key = "libsize_norm_log2_std", pseudobulk_layer_key="libsize_norm_log2_bulk_scaled", color_key="clustering_color", label_font_size =18, prototype_colors =  None, pseudobulk_colors =  None, pseudobulk_point_size=200, bulk_point_size=150):
    '''
    Custom 3D PCA projection of prototypes and pseudobulks. Colors 

    Parameters:
    - bulk_adata (AnnData): An AnnData object containing the prototype count matrix.
    - pseudobulk_adata(AnnData): An AnnData object containing the pseudobulk count matrix.
    - bulk_layer_key (str): The key for accessing the prototype layer for projection. Default 'libsize_norm_log2_std'.
    - pseudobulk_layer_key (str): The key for accessing the pseudobulk layer for projection. Default 'libsize_norm_log2_bulk_scaled'
    - color_key (str, optional): The key for accessing the cluster colors in the sc data. If provided, the pseudobulk points will be colored based on the cluster colors they originated from.
    - label_font_size (int): Font size of the labels on the PCA projection. 
    - prototype_colors (List[str]): A list of color codes to be used for plotting prototypes.
    - pseudobulk_colors (List[str]): A list of color codes to be used for plotting pseudobulks.
    - pseudobulk_point_size (int): Size of the pseudobulk point displayed on the plot.
    - bulk_point_size (int): Size of the prototype point displayed on the plot.

    Returns: 
    - 3D PCA projection figure.
    - PCA transformed values of prototypes.
    - PCA transformed values of pseudbulks.

    '''

    
    num_of_bulk_samples = bulk_adata.n_obs
    if num_of_bulk_samples >30:
        n_comp = 30
    else:
        n_comp = num_of_bulk_samples
    pca_bulk = PCA(n_components=n_comp)
    pca_bulk_train = pca_bulk.fit_transform(bulk_adata.layers[bulk_layer_key])
    PCs_pseudobulk_projection = pca_bulk.transform(pseudobulk_adata.layers[pseudobulk_layer_key])


    trained_bulk_pca_df = pd.DataFrame(data = pca_bulk_train
                 , columns = ["principal component " + str(i) for i in range(n_comp)])
    trained_bulk_pca_df["targets"] = bulk_adata.obs.index
    trained_bulk_pca_df

    projected_pseudobulk_pca_df = pd.DataFrame(data = PCs_pseudobulk_projection
                 , columns = ["principal component " + str(i) for i in range(n_comp)])
    projected_pseudobulk_pca_df["targets"] = pseudobulk_adata.obs.index
    projected_pseudobulk_pca_df

    trained_bulk_pca_df_w_labels = trained_bulk_pca_df.copy()
    trained_bulk_pca_df_w_labels["cell_type"] = trained_bulk_pca_df_w_labels['targets'].apply(lambda r: '_'.join(r.split('_')[:-1]))
    my_color=pd.Series(pd.Categorical(trained_bulk_pca_df_w_labels["cell_type"])).cat.codes
    trained_bulk_pca_df_w_labels["color_id"] = my_color
    ## plot
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    PC1 = trained_bulk_pca_df_w_labels['principal component 0'].values
    PC2 = trained_bulk_pca_df_w_labels['principal component 1'].values
    PC3 = trained_bulk_pca_df_w_labels['principal component 2'].values

    CELLTYPES = trained_bulk_pca_df_w_labels["cell_type"].values
    CELLTYPES_ = np.unique(CELLTYPES)
    num_bulk_cell_types= len(CELLTYPES_)
    # colors for bulk samples 
    if prototype_colors is None:
        COLORS = ['#38184C',  "#BDB0D9", "#82018F","#BAE33A", "#7ED9B7", "#008F8C", "#275974",'tab:red',
         '#170E9C',
         "tab:gray",
         "tab:pink","tab:green","tab:orange",
         '#C2EA8C',
         '#FB8B8C',
         '#41AC58',
         '#548E0F',
         '#59DE8C',
         '#68EBC0',
         '#6C397C',
         '#7B1A94',
         '#92F026',
         '#9C8244',
         '#9F84A8',
         '#A05529',
         '#AEB916',
         '#BB6AB9',
         '#C2EA8C',
         '#C3DB06',
         '#DB52E0',
         '#DD9340',
         '#E231B2',
         '#F1D7F2',
         '#F5A04D',
         '#FB8B8C']
    else:
        COLORS = prototype_colors
    for cell_type1, color in zip(CELLTYPES_, COLORS):
        idxs = np.where(CELLTYPES == cell_type1)
        # No legend will be generated if we don't pass label=species
        ax.scatter(
            PC1[idxs,], PC2[idxs,],PC3[idxs,], label=cell_type1,
            s=pseudobulk_point_size, color=color, alpha=0.7, marker = "v"
        )

    BULK_CELLTYPES = projected_pseudobulk_pca_df["targets"].values
    CELLTYPES_ = np.unique(BULK_CELLTYPES)
    PC1_ = projected_pseudobulk_pca_df['principal component 0'].values
    PC2_ = projected_pseudobulk_pca_df['principal component 1'].values
    PC3_ = projected_pseudobulk_pca_df['principal component 2'].values
    if pseudobulk_colors is None:
    # # get the color code frompseudobulk matrix:
        COLORS_ =pseudobulk_adata.uns[color_key]
    else: 
        COLORS_ = pseudobulk_colors
    for bulk_cell_type1, color in zip(CELLTYPES_, COLORS_):
        idxs = np.where(BULK_CELLTYPES == bulk_cell_type1)
        # No legend will be generated if we don't pass label=species
        ax.scatter(
            PC1_[idxs,], PC2_[idxs,],PC3_[idxs,], label=bulk_cell_type1,
            s=bulk_point_size, color=color, alpha=0.9)
        #ax.scatter(trained_pseudobulk_pca_df['principal component 1'], trained_pseudobulk_pca_df['principal component 2'], trained_pseudobulk_pca_df['principal component 3'], c=[4,5,6,7,8] ,cmap="Set2_r", s=60, marker = 'v')

    # put labels on the plot
    m= np.array([list(PC1_),list(PC2_),list(PC3_)])
    for i in range(len(m[0])): #plot each point + it's index as text above
        ax.text(m[0,i],m[1,i],m[2,i],  '%s' % ('  ' +BULK_CELLTYPES[i]), fontsize=label_font_size)


    #fig
    # ax.set_xlim((-150,120))   
    # ax.set_zlim((-50,50)) 
    # ax.set_ylim((0,150)) 
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")
    ax.set_zlabel("PC3")
    ax.set_facecolor('white')
    #ax.legend(loc='best', bbox_to_anchor=(0.9, 0.8, 0.6, 0.5));
    ax.legend( ncol=2,handleheight=2.4, labelspacing=0.05, bbox_to_anchor=(0.9, 0.5, 0.8, 0.5))
    figure = plt.gcf() # get current figure
    figure.set_size_inches(20 ,30)
    return fig, trained_bulk_pca_df_w_labels,projected_pseudobulk_pca_df

#################################################################################
# euclidean distance heatmap
##############################################################################

def plot_pca_dist_heatmap(trained_bulk_pca_df_w_labels,projected_pseudobulk_pca_df, cmap='Blues_r'):
    '''
    Plot a heatmap visualizing the pairwise Euclidean distances of prototypes and pseudobulks

    Parameters:
    - trained_bulk_pca_df_w_labels (DataFrame): DataFrame containing PCA components of trained prototypes with labels.
    - projected_pseudobulk_pca_df (DataFrame): DataFrame containing PCA components of projected pseudobulk data.
    - cmap (str, optional): Colormap for the heatmap. Default is 'Blues_r'.

    Returns:
    - tuple: A tuple containing:
        - sns.ClusterGrid: Seaborn ClusterGrid object representing the heatmap.
        - DataFrame: DataFrame containing the pairwise Euclidean distances.

    This function combines PCA components of projected pseudobulk data and trained prototype data,
    calculates the pairwise Euclidean distances, and plots a heatmap using Seaborn's clustermap.

    '''
    n_PC= projected_pseudobulk_pca_df.shape[1] -1
    #combine PCs
    pbulk_bulk_combined_pca_df = pd.concat([projected_pseudobulk_pca_df.iloc[:,0:n_PC], trained_bulk_pca_df_w_labels.iloc[:,0:n_PC]])
    names = list(projected_pseudobulk_pca_df["targets"])+list(trained_bulk_pca_df_w_labels["targets"])
    pbulk_bulk_combined_pca_df.index =names
    euclidean_dis=pdist(pbulk_bulk_combined_pca_df.iloc[:,0:n_PC].to_numpy(), 'euclidean')
    euclidean_dis_df = pd.DataFrame(squareform(euclidean_dis))
    euclidean_dis_df.index = names
    euclidean_dis_df.columns = names
    g = sns.clustermap(euclidean_dis_df,yticklabels=True,xticklabels=True,cmap=cmap)
    return g, euclidean_dis_df

def plot_pca_dist_cent_heatmap(trained_bulk_pca_df_w_labels,projected_pseudobulk_pca_df, cmap='Blues_r'):
    '''
    Plot a heatmap visualizing the pairwise Euclidean distances between centroids of prorotypes and pseudobulks.

    Parameters:
    - trained_bulk_pca_df_w_labels (DataFrame): DataFrame containing PCA components of trained bulk data with labels.
    - projected_pseudobulk_pca_df (DataFrame): DataFrame containing PCA components of projected pseudobulk data.
    - cmap (str, optional): Colormap for the heatmap. Default is 'Blues_r'.

    Returns:
    - tuple: A tuple containing:
        - sns.ClusterGrid: Seaborn ClusterGrid object representing the heatmap.
        - DataFrame: DataFrame containing the pairwise Euclidean distances.

    This function combines PCA components of projected pseudobulk data and trained prototype data,
    calculates centroids for trained prototype data, and plots a heatmap using Seaborn's clustermap.

    '''
   
    n_PC= projected_pseudobulk_pca_df.shape[1] -1
    trained_bulk_pca_df_w_labels_centroid = trained_bulk_pca_df_w_labels.groupby('cell_type')[trained_bulk_pca_df_w_labels.columns[0:n_PC]].agg('mean')
    # combine centrodis and pbulk dfs and calculate pairwise distances
    pbulk_bulk_centrid_combined_pca_df = pd.concat([projected_pseudobulk_pca_df.iloc[:,0:n_PC], trained_bulk_pca_df_w_labels_centroid.iloc[:,0:n_PC]])
    df_names = [name+"_pbulk" for name in list(projected_pseudobulk_pca_df["targets"])] +list(trained_bulk_pca_df_w_labels_centroid.index) 
    pbulk_bulk_centrid_combined_pca_df.index = df_names
    pbulk_bulk_centrid_euclidean_dis=pdist(pbulk_bulk_centrid_combined_pca_df.to_numpy(), 'euclidean')
    pbulk_bulk_centrid_euclidean_dis_df = pd.DataFrame(squareform(pbulk_bulk_centrid_euclidean_dis))
    pbulk_bulk_centrid_euclidean_dis_df.index = df_names
    pbulk_bulk_centrid_euclidean_dis_df.columns = df_names
    g = sns.clustermap(pbulk_bulk_centrid_euclidean_dis_df,yticklabels=True,xticklabels=True, cmap=cmap)
    
    return g, pbulk_bulk_centrid_euclidean_dis_df


def plot_gene_activity_of_UMAP(adata, gene_name, activity_matrix, out_path, point_size=22):
    '''
    Plot UMAP embedding of the given genes' activity across single cells. 

    Parameters:
    - adata (AnnData): An AnnData object containing the sc count matrix.
    - gene_name (str): Name of the gene.
    - activity_matrix (DataFrame): Gene activity score of the gene across cells. (Rows:cells x columns:genes (str))
    - out_path (str): The path to the output directory. 
    - point_size: Size of the cell points displayed on the UMAP.

    Returns:
    - None

    This function saves a Matplotlib figure to the specified file path.
    
    '''
    if gene_name not in activity_matrix.index:
        print("this gene is not included in the gene activity matrix")
        return
    else:
        # scale the gene 0-1
        gene_df = pd.DataFrame(activity_matrix.loc[gene_name,:])
        x = gene_df.values #returns a numpy array
        min_max_scaler = preprocessing.MinMaxScaler()
        x_scaled = min_max_scaler.fit_transform(x)
        gene_df_scaled = pd.DataFrame(x_scaled)
        gene_df_scaled.index = gene_df.index
        adata.obs[gene_name] = gene_df_scaled.loc[adata.obs.index,]
        with plt.rc_context():  # Use this to set figure params like size and dpi
            sc.pl.umap(
            adata,
            color=gene_name,
            cmap=sns.blend_palette(["lightgray", "#6A99D0"], as_cmap=True),
            add_outline=False, frameon=False, title ="", save=False, size=point_size,
            legend_fontsize='xx-small’')
            plt.savefig(out_path, bbox_inches="tight")
        